#coding=utf-8
import os
import json
import requests
import numpy as np
from sklearn.metrics import roc_auc_score
from process_data import main_process



def predict_serving(label_path, train_path):
    f1 = open(label_path, 'r')
    f3 = open(label_path, 'r')
    f2 = open(train_path, 'r')
   

    # keep clicked users 
    eff_user = set()
    for l in f1.readlines():
        l = l.strip().split(' ')
        uid = l[0]
        label = l[2]
        if label == '1':
            eff_user.add(uid)


    # test_uid & train_uid
    raw_data = {}
    for l in f2.readlines():
        l = l.strip().split(' ')
        uid = l[0]
        gid = l[1]
        if uid in eff_user:
            uuid = 'user_'+uid
            if not uuid in raw_data:
                raw_data[uuid] = []
                raw_data[uuid].append(['item_'+gid])
            else:
                raw_data[uuid][0] += ['item_'+gid]


    # get user label list
    true_click = {}
    for l in f3.readlines():
        l = l.strip().split(' ')
        uid = l[0]
        uuid = 'user_'+uid
        gid = 'item_'+l[1]
        label = int(l[2])
        if uuid in raw_data:
            if not uuid in true_click:
                true_click[uuid] = {}
                true_click[uuid]['items'] = []
                true_click[uuid]['labels'] = []
                true_click[uuid]['items'].extend([gid])
                true_click[uuid]['labels'].extend([label])
            else:
                true_click[uuid]['items'].extend([gid])
                true_click[uuid]['labels'].extend([label])
        if uuid in raw_data:
            if len(true_click[uuid]['items']) != len(true_click[uuid]['labels']):           
                print(len(true_click[uuid]['items']), len(true_click[uuid]['labels']))           


    # predict
    url = 'http://localhost:8501/v1/models/bert_model:predict'
    probs = {}
    for i, u in enumerate(raw_data):
        feature = main_process({u:raw_data[u]})        
        data = json.dumps({"instances":[feature]})
        #call serving
        response = requests.post(url, data=data)
        print(i)
        result = response.json()
        result = result['predictions']
        pred_item = {i['output']:i['prob'] for i in result}
        for it in iter(true_click[u]['items']):
            if not u in probs:
                probs[u] = []
                if it in pred_item:
                    probs[u].append(float(pred_item[it]))
                else:
                    probs[u].append(0.0)
            else:
                if it in pred_item:
                    probs[u].append(float(pred_item[it]))
                else:
                    probs[u].append(0.0)
     

    #fe = main_process({'user_156619082615898800':raw_data['user_156619082615898800']})
    #data = json.dumps({"instances":[fe]})
    #response = requests.post(url, data=data)
    #print(len(true_click['user_156619082615898800']['items']))
    #print(len(response.json()['predictions']))
              

    # calculate auc
    save_path = './auc.txt'
    if os.path.exists(save_path):
         os.remove(save_path)
    result_f = open(save_path, 'w')
    auc = {}
    for u in probs:
        print(u)
        prob_arr = np.array(probs[u])
        label_arr = np.array(true_click[u]['labels'])
        print('prob:{}, label:{}'.format(prob_arr, label_arr))
        try:
            score = roc_auc_score(label_arr, prob_arr)
        except:
            score = 0.5
        print('user:{}, score:{}'.format(u, str(score)))
        with open(save_path, 'a') as f:
            f.write(u+' '+str(score)+'\t\n')
        

            

if __name__ == "__main__":
    predict_serving(label_path='/data/click_history/record_file/click_history_with_label.txt', train_path='/data/click_history/record_file/click_history.txt')
