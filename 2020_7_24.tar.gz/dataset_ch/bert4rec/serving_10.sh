#curl -X POST -d '{"instances":[{
#"info":[156620031644414962],
#"input_ids":[336, 340, 18, 691, 691, 3052, 0, 0, 0, 0],
#"input_mask":[1, 1, 1, 1, 1, 1, 0, 0, 0, 0],
#"masked_lm_positions":[5, 0, 0, 0, 0],
#"masked_lm_ids":[167, 0, 0, 0, 0],
#"masked_lm_weights":[1.0, 0.0, 0.0, 0.0, 0.0]
#}]}' http://localhost:8501/v1/models/bert_model:predict > ./log/log_serving.txt




curl -X POST -d '{"instances":[{
"info":[156620031242564255],
"input_ids":[181, 407, 335, 3039, 0, 0, 0, 0, 0, 0],
"input_mask":[1, 1, 1, 1, 0, 0, 0, 0, 0, 0],
"masked_lm_positions":[3, 0, 0, 0, 0],
"masked_lm_ids":[91, 0, 0, 0, 0],
"masked_lm_weights":[1.0, 0.0, 0.0, 0.0, 0.0]
}]}' http://localhost:8501/v1/models/bert_model:predict > ./log/log_serving.txt
            
