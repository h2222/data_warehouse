# -*- coding: utf-8 -*-
import json
import sys
import time
from datetime import datetime, timedelta

from init_spark import init_spark
from params import BaseParams


def mapper1(x):
    try:
        tmp = json.loads(x)
        label = int(tmp["label"])
        if label == 0:
            return
        uid = int(tmp["user_id"])
        gid = int(tmp["good_id"])
        ts = int(tmp["ts"])
        return uid, (gid, ts)
    except:
        pass


def sort_d(x):
    x = list(x)
    value = x[1]
    value.sort(key=lambda x: x[1])
    x[1] = value
    return tuple(x)


def get_dataset(start_dt, days=7):
    data = sc.parallelize([])
    dt = datetime.strptime(start_dt, '%Y-%m-%d')
    for i in range(days):
        try:
            cur_dt = dt - timedelta(days=i)
            ret = sc.textFile(
                "oss://opay-datalake/algo_migration/omall/event_label/dt=%s/*" % cur_dt.strftime('%Y-%m-%d'))
            data = data.union(ret)
            print(cur_dt)
        except:
            pass
    data.map(mapper1)\
        .filter(lambda x: x is not None)\
        .groupByKey()\
        .mapValues(list)\
        .map(sort_d)\
        .filter(lambda x: x is not None)\
        .map(lambda (uid, click_history): json.dumps({"user_id": uid, "click_history": click_history}))\
        .filter(lambda x: x is not None)\
        .repartition(1)\
        .saveAsTextFile("/tmp/research/mall_%s_%s_%d/" %("click_history", start_dt, days),
                         compressionCodecClass="org.apache.hadoop.io.compress.GzipCodec")


if __name__ == "__main__":
    p = BaseParams()
    spark, sc = init_spark("click_history")
    sc.setLogLevel("ERROR")

    dt = int(p.days) if p.days is not None else 28
    train_dt = str(p.date) if p.date is not None else time.strftime('%Y-%m-%d',time.localtime(time.time() - 86400 * (1 + dt)))    
    get_dataset(train_dt, dt)    
