import sys
import time



if __name__ == "__main__":
    d1 = int(sys.argv[1]) if len(sys.argv) > 1 else 28
    d2 = int(sys.argv[2]) if len(sys.argv) > 2 else 60
    train_dt = sys.argv[3] if len(sys.argv) > 3 else time.strftime('%Y-%m-%d',time.localtime(time.time() - 86400 * (1 + d2)))
    
    print(train_dt)
    print(sys.argv)
