#coding=utf-8


class BaseParams:
    def __init__(self):
        self.data_dir='/data/click_history/'
        self.CKPT_DIR = "/ckpt_save_path"
        self.dataset_name = "part-00000"
        
        self.max_seq_length = 20
        self.max_predictions_per_seq = 10
        self.masked_lm_prob = 0.6
        self.dim = 64
        self.batch_size = 256
        self.num_train_steps = 400000
        self.mask_prob = 1.0
        self.prop_sliding_window = 0.1
        self.dupe_factor = 1 #10
        self.pool_size = 1   #10

        self.signature = "-mp"+str(self.mask_prob)+"-sw"+str(self.prop_sliding_window)\
                         +"-mlp"+str(self.masked_lm_prob)+"-df"+str(self.dupe_factor)\
                         +"-mpps"+str(self.max_predictions_per_seq)+"-msl"+str(self.max_seq_length)\
                         +"-dim"+str(self.dim)
        

        # download click history by days
        self.date = '2020-07-01'  # before dates(YYYY-MM-dd)
        self.days = 100 # download x days
        # data download path
        self.data_path = "/data/"
