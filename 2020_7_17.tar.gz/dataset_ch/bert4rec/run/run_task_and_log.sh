nohup /usr/bin/sh run_click_history_256.sh > ../log/log_256.txt 2>&1 &
tail -f ../log/log_256.txt
