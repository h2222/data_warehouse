# -*- coding: UTF-8 -*-
import pickle
import codecs
import collections

from util import *
from vocab import *


class TrainingInstance(object):
    """A single training instance (sentence pair)."""

    def __init__(self, info, tokens, masked_lm_positions, masked_lm_labels):
        self.info = info  # info = [user]
        self.tokens = tokens
        self.masked_lm_positions = masked_lm_positions
        self.masked_lm_labels = masked_lm_labels

    def __str__(self):
        s = ""
        s += "info: %s\n" % (" ".join([str(x) for x in self.info]))
        s += "tokens: %s\n" % (
            " ".join([str(x) for x in self.tokens]))
        s += "masked_lm_positions: %s\n" % (
            " ".join([str(x) for x in self.masked_lm_positions]))
        s += "masked_lm_labels: %s\n" % (
            " ".join([str(x) for x in self.masked_lm_labels]))
        s += "\n"
        return s

    def __repr__(self):
        return self.__str__()


def serving_input_dict(instance, 
                       max_seq_length,
                       max_predictions_per_seq, 
                       vocab):
    features = {}
    try:
        input_ids = vocab.convert_tokens_to_ids(instance.tokens)
        print('good instance, and input_ids is :')
        print(input_ids) # item index based on term-frequence
    except:
        print('bad instance')
        print(instance)

    ## input index list and input mask list(all one)
    input_mask = [1] * len(input_ids)
    assert len(input_ids) <= max_seq_length
    # with padding
    input_ids += [0] * (max_seq_length - len(input_ids))
    input_mask += [0] * (max_seq_length - len(input_mask))
    assert len(input_ids) == max_seq_length
    assert len(input_mask) == max_seq_length

    ## masked language model position list, index list(based on term-frequence), weight list, 
    masked_lm_positions = list(instance.masked_lm_positions)
    masked_lm_ids = vocab.convert_tokens_to_ids(instance.masked_lm_labels)
    masked_lm_weights = [1.0] * len(masked_lm_ids)
    # with padding
    masked_lm_positions += [0] * (max_predictions_per_seq - len(masked_lm_positions))
    masked_lm_ids += [0] * (max_predictions_per_seq - len(masked_lm_ids))
    masked_lm_weights += [0.0] * (max_predictions_per_seq - len(masked_lm_weights))

    features["info"] = instance.info
    features["input_ids"] = input_ids
    features["input_mask"] = input_mask
    features["masked_lm_positions"] = masked_lm_positions
    features["masked_lm_ids"] = masked_lm_ids
    features["masked_lm_weights"] = masked_lm_weights
    print(features)

    return features


def create_predict_instances(data, max_seq_length):
    for k, v in data.items():
        if len(data[k][0]) == 0:
            raise Exception("no items choose !")
        elif len(data[k][0]) > max_seq_length:
            data[k] = [data[k][0][-max_seq_length:]]

    instance = create_instances_from_document_test(data)
    print(instance)
    return instance


def create_instances_from_document_test(data):
    """ (keep) Creates `TrainingInstance`s for a single document."""
    assert len(data.keys()) == 1
    user = list(data.keys())[0]
    document = data[user]
    tokens = document[0]
    tokens, masked_lm_positions, masked_lm_labels = create_masked_lm_predictions_force_last(tokens)
    info = [int(user.split("_")[1])]
    instance = TrainingInstance(info=info, # user id
                                tokens=tokens, # token list
                                masked_lm_positions=masked_lm_positions, # masked token position index
                                masked_lm_labels=masked_lm_labels) # masked token id
    return instance


def create_masked_lm_predictions_force_last(tokens):
    """(keep) Creates the predictions for the masked LM objective."""

    last_index = -1
    last_index = tokens.index(tokens[-1])
    assert last_index > -1

    output_tokens = list(tokens) # to_list, deep cp
    output_tokens[last_index] = "[MASK]"    
    masked_lm_positions = [last_index]
    masked_lm_labels = [tokens[last_index]]
    return (output_tokens, masked_lm_positions, masked_lm_labels)


def gen_samples_for_predict(data,
                            max_seq_length,
                            vocab,
                            max_predictions_per_seq):
    # create train
    instance = create_predict_instances(data, max_seq_length)
    features = serving_input_dict(instance, 
                       max_seq_length,
                       max_predictions_per_seq, 
                       vocab)
    return features


def main_process(data):
    # max_seq_length, max_prediction_per_seq
    max_seq_length = 10
    max_predictions_per_seq = 5
    vocab_file_name = '/data/click_history/record_file/click_history-mp1.0-sw0.1-mlp0.6-df15-mpps30-msl50.vocab'
    #vocab file
    with open(vocab_file_name, 'rb') as f:
        vocab = pickle.load(f)
    features = gen_samples_for_predict(data,
                                       max_seq_length,
                                       vocab,
                                       max_predictions_per_seq)
    return features



if __name__ == "__main__":
    # test example
    data = {'user_156620010657412563':[['item_1181161', 'item_1181880', 'item_1182468', 'item_1181191', 'item_1183892', 'item_1184003', 'item_1184245','item_1183868']]}
    main_process(data)
