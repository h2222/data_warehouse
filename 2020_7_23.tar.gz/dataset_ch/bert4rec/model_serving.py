#import os
#from flask import Flask, request, jsonify
import json
import requests
#from  util import data_departition
from process_data import main_process



def predict_serving(label_path, train_path):
    f1 = open(label_path, 'r')
    f2 = open(train_path, 'r')
   
    # keep clicked users 
    eff_user = set()
    true_click = {}
    for l in f1.readlines():
        l = l.strip().split(' ')
        uid = l[0]
        uuid = 'user_'+l[0]
        gid = 'item_'+l[1]
        label = l[2]
        if label == '1':
            eff_user.add(uid)
            if not uuid in true_click:
                true_click[uuid] = []
                true_click[uuid] += [gid]
            else:
                true_click[uuid] += [gid]

    # test_uid & train_uid
    raw_data = {}
    for l in f2.readlines():
        l = l.strip().split(' ')
        uid = l[0]
        gid = l[1]
        if uid in eff_user:
            uid = 'user_'+uid
            if not uid in raw_data:
                raw_data[uid] = []
                raw_data[uid].append(['item_'+gid])
            else:
                raw_data[uid][0] += ['item_'+gid]
    # predict
    url = 'http://localhost:8501/v1/models/bert_model:predict'
    auc = {}
    for u in raw_data:
        if raw_data[u][0] > 2:
            feature = main_process({u:raw_data[u]})        
            data = json.dumps({"instances":[feature]})
            #call serving
            response = requests.post(url, data=data)
            result = response.json()
            result = result['predictions']
            for i in result:
                pred_item = i['output']
                prob = i['prob']
                #print(pred_item)
                if pred_item in true_click[u]:
                    print('good'*100)
                    auc[pred_item] = prob    


    print(len(raw_data))
    print(auc)

   
    
    








if __name__ == "__main__":
    predict_serving(label_path='/data/click_history/record_file/click_history_with_label.txt', train_path='/data/click_history/record_file/click_history.txt')
