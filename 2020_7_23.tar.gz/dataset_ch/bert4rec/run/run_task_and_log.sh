nohup /usr/bin/sh run_click_history_64.sh > ../log/log_64_serving.txt 2>&1 &
tail -f ../log/log_64_serving.txt
